// Need a placeholder for complilation for now.
class HTTPClient {};
