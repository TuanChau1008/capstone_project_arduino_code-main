FirebaseArduino is a library to simplify connecting to the Firebase database from
arduino clients.

It is a full abstraction of Firebase's REST API exposed through C++ calls in a wiring
friendly way. All Json parsing is handled by the library and you may deal in pure C/Arduino
types.

----------------------------------
